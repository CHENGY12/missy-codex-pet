#!/bin/zsh
set -eu

bundle_dir="${0:A:h}"
pet_source="${bundle_dir}/missy"
codex_root="${CODEX_HOME:-${HOME}/.codex}"
pet_target="${codex_root}/pets/missy"

if [[ -e "${pet_target}" ]]; then
  print -u2 "A pet named missy already exists at ${pet_target}. Nothing was overwritten."
  exit 1
fi

mkdir -p "${pet_target}"
cp "${pet_source}/pet.json" "${pet_target}/pet.json"
cp "${pet_source}/spritesheet.webp" "${pet_target}/spritesheet.webp"
print "Missy (v2.3.1) was installed at ${pet_target}."
