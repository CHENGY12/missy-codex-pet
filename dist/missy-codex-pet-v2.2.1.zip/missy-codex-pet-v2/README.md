# Missy — Codex Pet v2

Missy Stretch & Meow v2.2.1 is a shareable custom animated pet for the Codex desktop app. The package contains the approved `1536 × 2288` WebP sprite sheet, 9 standard animation rows, and 16 looking directions.

In v2.2.1, Missy's idle body is horizontally registered while her height and feet baseline stay fixed. Her eyelids blink and her tail follows a broader, smoother arc. The preview is generated from the final despilled atlas, so it has no blue edge. Running, stretch-and-meow, review, and look-direction animations are unchanged from v2.1.2.

No API key is required to install or use Missy. The original reference photographs are not included.

## Quick install on macOS

1. Unzip the download.
2. Double-click `install.command`.
3. Open Codex and go to **Settings > Pets**.
4. Select **Refresh**, choose **Missy**, and use `/pet` or **Wake Pet** if she is tucked away.

If macOS prevents the installer from opening, open Terminal in this folder and run:

```sh
./install.command
```

The installer refuses to overwrite an existing pet named `missy`; preserve or remove the existing folder first if you are upgrading manually.

## Manual install

Copy the included `missy` folder to:

```text
~/.codex/pets/missy
```

The installed folder must contain both `pet.json` and `spritesheet.webp`. Then refresh **Settings > Pets**.

## One-click install link for a website

If you host `missy/spritesheet.webp` at a public absolute HTTPS URL, you can publish a Codex deep link in this form:

```text
codex://pets/install?name=Missy%20Stretch%20%26%20Meow%20(v2.2.1)&imageUrl=<URL-ENCODED-HTTPS-SPRITESHEET-URL>&description=Missy%20the%20calico%20cat%20with%20a%20registered%20stable%20idle%20animation&spriteVersionNumber=2
```

The `imageUrl` must be an absolute HTTPS URL and `spriteVersionNumber=2` must remain in the link.

## 中文安装

1. 解压下载包。
2. 双击 `install.command`。
3. 打开 Codex 的 **Settings > Pets**。
4. 点击 **Refresh**，选择 **Missy**；如未显示宠物，输入 `/pet` 或选择 **Wake Pet**。

也可以手动把 `missy` 文件夹复制到 `~/.codex/pets/missy`。v2.2.1 的静止动画会锁定水平位置、身体高度和脚底线，只保留眨眼与幅度更大、更自然的摆尾；预览也已去除蓝边。其他动作与 v2.1.2 保持一致。安装和使用均不需要 API Key。
