#!/bin/zsh
set -eu

bundle_dir="${0:A:h}"
pet_source="${bundle_dir}/missy"
codex_root="${CODEX_HOME:-${HOME}/.codex}"
pets_root="${codex_root}/pets"
pet_target="${pets_root}/missy"

if [[ ! -f "${pet_source}/pet.json" || ! -f "${pet_source}/spritesheet.webp" ]]; then
  print -u2 "Missy package is incomplete. Keep install.command next to the missy folder."
  exit 1
fi

if [[ -e "${pet_target}" ]]; then
  print -u2 "A pet named missy already exists at ${pet_target}. Nothing was overwritten."
  exit 1
fi

mkdir -p "${pet_target}"
cp "${pet_source}/pet.json" "${pet_target}/pet.json"
cp "${pet_source}/spritesheet.webp" "${pet_target}/spritesheet.webp"

print "Missy was installed at ${pet_target}."
print "Open Codex > Settings > Pets, select Refresh, and choose Missy."
