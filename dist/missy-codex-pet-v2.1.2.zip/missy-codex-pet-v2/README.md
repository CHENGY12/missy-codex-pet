# Missy Stretch & Meow — v2.1.2

Missy v2.1.2 is the corrected stretch-and-meow edition for the Codex desktop app. It keeps the blue-fringe repair from v2.1.1 and replaces the left-running row with a framewise mirror of the approved right-running gait, removing the old purple-red whisker tint while preserving timing. All other rows and all 16 look directions are unchanged.

No API key is required. Original reference photographs are not included.

## Quick install on macOS

1. Unzip the download.
2. Double-click `install.command`.
3. Open Codex and go to **Settings > Pets**.
4. Select **Refresh**, then choose **Missy Stretch & Meow (v2.1.2)**.

For side-by-side installation with the original edition, use the repository commands:

```sh
npx --yes github:CHENGY12/missy-codex-pet add missy@2.1.2
npx --yes github:CHENGY12/missy-codex-pet add missy@2.0.0
```

These install as two distinct pets:

- Missy Stretch & Meow (v2.1.2)
- Missy Original (v2.0.0)

## 中文安装

1. 解压下载包。
2. 双击 `install.command`。
3. 打开 Codex 的 **Settings > Pets**，点击 **Refresh**。
4. 选择 **Missy Stretch & Meow (v2.1.2)**。

v2.1.2 保留了 running 动画的蓝幕残色修复，并修复向左跑时胡须的紫红色。只有 running-left 行发生变化；其他动作与 look 方向保持不变。两个命令安装版本使用不同名称，可以同时保留。
