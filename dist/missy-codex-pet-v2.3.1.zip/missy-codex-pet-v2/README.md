# Missy Poop, Peek & Run — v2.3.1

This release combines Missy's stable idle, stretch-and-meow work animation, cute non-graphic poop-and-peek failure, correct native left-running ear markings, and 16 look directions.

Run `npx --yes github:CHENGY12/missy-codex-pet add missy@2.3.1 --force` to preserve an existing Missy as a backup and install this version.

本版本合并稳定静止动画、伸懒腰并叫的工作动画、可爱非写实的拉屎失败动作，并修正向左跑时不对称耳朵花纹的方向。
