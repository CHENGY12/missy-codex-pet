# Missy Poop & Peek — v2.2.0

Missy v2.2.0 adds a cute, non-graphic poop-and-peek sequence to the Codex `failed` state. Missy glances back, squats, leaves a tiny cartoon poop, relaxes, and looks back with an embarrassed expression. The other eight standard action rows and all 16 look directions are unchanged from v2.1.2.

## Quick install on macOS

1. Unzip the download.
2. Double-click `install.command`.
3. Open Codex and go to **Settings > Pets**.
4. Select **Refresh**, then choose **Missy Poop & Peek (v2.2.0)**.

The ZIP installer refuses to overwrite an existing `missy` folder. Use the repository command with `--force` to preserve the current folder as a backup and install this edition:

```sh
npx --yes github:CHENGY12/missy-codex-pet add missy@2.2.0 --force
```

## 中文安装

1. 解压下载包。
2. 双击 `install.command`。
3. 打开 Codex 的 **Settings > Pets**，点击 **Refresh**。
4. 选择 **Missy Poop & Peek (v2.2.0)**。

v2.2.0 把任务失败时的 `failed` 动画改为可爱、非写实的“回头—蹲下—留下一个小卡通便便—松气—尴尬回望”动作；其余动作和 16 个 look 方向保持 v2.1.2 原样。
