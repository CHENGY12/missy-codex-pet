# Missy — Codex Pet v2.1.0

Missy v2.1.0 is a shareable custom animated calico-cat pet for the Codex desktop app. This release changes only the active-work `running` row: Missy stretches, lifts her head, visibly meows, and settles. The other eight standard actions and all 16 looking directions are unchanged from v2.0.0.

No API key is required. Original reference photographs are not included.

## Quick install on macOS

1. Unzip the download.
2. Double-click `install.command`.
3. Open Codex and go to **Settings > Pets**.
4. Select **Refresh**, choose **Missy**, and use `/pet` or **Wake Pet** if needed.

The ZIP installer refuses to overwrite an existing `missy` folder. To switch versions safely with an automatic backup, use the repository command instead:

```sh
npx --yes github:CHENGY12/missy-codex-pet add missy@2.1.0 --force
```

The original v2.0.0 remains available:

```sh
npx --yes github:CHENGY12/missy-codex-pet add missy@2.0.0 --force
```

## Manual install

Copy the included `missy` folder to `~/.codex/pets/missy`, then refresh **Settings > Pets**.

## Look directions

Rows 9 and 10 contain all 16 v2 look directions and are unchanged. The current Codex renderer drives these poses from its Computer Use cursor event; ordinary mouse movement and dragging the pet do not trigger them.

## 中文安装

1. 解压下载包。
2. 双击 `install.command`。
3. 打开 Codex 的 **Settings > Pets**。
4. 点击 **Refresh**，选择 **Missy**。

v2.1.0 只修改工作中的 `running` 动作，改为伸懒腰、抬头张嘴叫、再收势；其余动作和 16 个 look 方向均保持 v2.0.0 原样。安装和使用不需要 API Key。
