# Missy — Codex Pet v2

Missy is a shareable custom animated pet for the Codex desktop app. The package contains the approved `1536 × 2288` WebP sprite sheet, 9 standard animation rows, and 16 looking directions.

No API key is required to install or use Missy. The original reference photographs are not included.

## Quick install on macOS

1. Unzip the download.
2. Double-click `install.command`.
3. Open Codex and go to **Settings > Pets**.
4. Select **Refresh**, choose **Missy**, and use `/pet` or **Wake Pet** if she is tucked away.

If macOS prevents the installer from opening, open Terminal in this folder and run:

```sh
./install.command
```

The installer refuses to overwrite an existing pet named `missy`.

## Manual install

Copy the included `missy` folder to:

```text
~/.codex/pets/missy
```

The installed folder must contain both `pet.json` and `spritesheet.webp`. Then refresh **Settings > Pets**.

## One-click install link for a website

If you host `missy/spritesheet.webp` at a public absolute HTTPS URL, you can publish a Codex deep link in this form:

```text
codex://pets/install?name=Missy&imageUrl=<URL-ENCODED-HTTPS-SPRITESHEET-URL>&description=Missy%20the%20calico%20cat&spriteVersionNumber=2
```

The `imageUrl` must be an absolute HTTPS URL and `spriteVersionNumber=2` must remain in the link.

## 中文安装

1. 解压下载包。
2. 双击 `install.command`。
3. 打开 Codex 的 **Settings > Pets**。
4. 点击 **Refresh**，选择 **Missy**；如未显示宠物，输入 `/pet` 或选择 **Wake Pet**。

也可以手动把 `missy` 文件夹复制到 `~/.codex/pets/missy`。安装和使用均不需要 API Key。
