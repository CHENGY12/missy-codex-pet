# Missy (v2.3.2)

Missy is a lovable little calico cat who keeps you company and playfully interacts with you while you work.

This release gives the `waving` state a natural lick-paw-and-wash-face grooming loop and removes detached black source-edge fragments from the `failed` poop-and-peek animation. Every other animation row is pixel-identical to v2.3.1.

Install with:

```sh
npx --yes github:CHENGY12/missy-codex-pet add missy@2.3.2 --force
```
