# Missy Stretch & Meow — v2.1.1

Missy v2.1.1 is the corrected stretch-and-meow edition for the Codex desktop app. This patch removes blue chroma-key fringe from the running animation's whiskers and outline. The stretch-and-meow motion, all other standard actions, and all 16 look directions are preserved.

No API key is required. Original reference photographs are not included.

## Quick install on macOS

1. Unzip the download.
2. Double-click `install.command`.
3. Open Codex and go to **Settings > Pets**.
4. Select **Refresh**, then choose **Missy Stretch & Meow (v2.1.1)**.

For side-by-side installation with the original edition, use the repository commands:

```sh
npx --yes github:CHENGY12/missy-codex-pet add missy@2.1.1
npx --yes github:CHENGY12/missy-codex-pet add missy@2.0.0
```

These install as two distinct pets:

- Missy Stretch & Meow (v2.1.1)
- Missy Original (v2.0.0)

## 中文安装

1. 解压下载包。
2. 双击 `install.command`。
3. 打开 Codex 的 **Settings > Pets**，点击 **Refresh**。
4. 选择 **Missy Stretch & Meow (v2.1.1)**。

v2.1.1 清除了新版 running 动画胡须和轮廓上的蓝幕残色，没有修改动作内容、其他动作或 look 方向。两个命令安装版本使用不同名称，可以同时保留。
